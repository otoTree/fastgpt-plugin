---
name: tool-dev
description: Specialized skill for developing FastGPT system tools and toolsets with type-safe Zod validation, shared configuration management, and comprehensive testing workflows. Use this skill when creating new FastGPT tools, developing toolsets with child tools, or implementing API integrations with proper configuration and testing.
license: MIT
category: development
author: FastGPT Team
version: 2.0.0
---

# FastGPT Tool Development Skill

Streamlined workflow for developing FastGPT system tools with type safety, proper configuration management, and automated testing.

## When to Use This Skill

Use this skill when working on FastGPT tool development tasks:
- Creating new independent tools or toolsets
- Implementing API integrations with proper authentication
- Developing tools with Zod validation and TypeScript types
- Setting up shared configuration across toolset children
- Writing comprehensive tests for tool functionality

## Core Capabilities

- **Type-Safe Development**: Zod schema validation + TypeScript inference
- **Configuration Management**: Shared secrets across toolsets with version control
- **Systematic Testing**: Automated test generation and validation
- **Code Quality**: Built-in review and optimization steps
- **Best Practices**: Follows FastGPT design patterns and conventions

---

## Development Workflow

Follow this 4-phase workflow when developing FastGPT tools. Each phase has specific objectives, actions, and quality gates.

### Phase 1: Requirements & Design

**Objective**: Create comprehensive requirement document

**Actions**:
1. Review existing design patterns in `references/design_spec.md`
2. Define tool/toolset scope and functionality
3. Specify input/output configurations using Zod schemas
4. Document API requirements and test credentials
5. Use `references/requirement_template.md` as starting point

**Quality Gates**:
- ✅ All functionality clearly defined
- ✅ Input/output types specified
- ✅ Edge cases and error scenarios documented

**Deliverable**: Complete design document (see `references/requirement_template.md`)

---

### Phase 2: Implementation

**Objective**: Develop tool following FastGPT patterns

**Actions**:
1. Create directory structure (`tool/` or `toolset/children/`)
2. Implement `config.ts` with proper version list
3. Develop `src/index.ts` with Zod-validated business logic
4. Add shared modules (`client.ts`, `utils.ts`) if needed

**Code Standards**:
- camelCase naming convention
- Type imports: `import { type Foo } from 'bar'`
- Minimal error handling (let framework handle common cases)
- Small, focused functions

**Quality Gates**:
- ✅ TypeScript compiles without errors
- ✅ Follows existing project patterns
- ✅ Configuration properly structured

---

### Phase 3: Testing & Validation

**Objective**: Ensure reliability through comprehensive testing

**Actions**:
1. Install dependencies: `bun install`
2. Write test cases in `test/index.test.ts`
3. Run test suite: `bun test`
4. Fix failures and edge cases
5. Validate TypeScript: `bun run tsc --noEmit`

**Test Coverage**:
- Input validation (Zod schema edge cases)
- Business logic correctness
- Error handling scenarios
- Resource cleanup (if applicable)

**Quality Gates**:
- ✅ All tests passing
- ✅ No TypeScript errors
- ✅ Build succeeds: `bun run build`

---

### Phase 4: Review & Optimization

**Objective**: Refine code quality before finalization

**Actions**:
1. Code review for simplification opportunities
2. Remove unused code and dependencies
3. Optimize performance bottlenecks
4. Final integration test
5. Update documentation

**Quality Gates**:
- ✅ Code is clean and maintainable
- ✅ No unnecessary complexity
- ✅ Final test run successful

---

## Quick Reference

### Common Commands
```bash
# Install dependencies
bun install

# Run tests
bun test

# Type check
bun run tsc --noEmit

# Build
bun run build

# Test specific file
bun test test/index.test.ts
```

### File Templates
Access detailed templates and specifications:
- **Requirement Template**: `references/requirement_template.md`
- **Full Design Spec**: `references/design_spec.md`
- **Tool Config Examples**: Section 4.1 in design_spec.md
- **ToolSet Config Examples**: Section 5.1 in design_spec.md
- **Zod Validation Patterns**: Section 7.2 in design_spec.md
- **Test Structure**: Section 9.1 in design_spec.md

### Key Design Principles
1. **Separation of Concerns**: Config ≠ Logic ≠ Tools
2. **Type Safety**: Zod validation → TypeScript inference
3. **Shared Configuration**: ToolSet secrets inherited by children
4. **Single Responsibility**: One tool = One function
5. **Fail Fast**: Let framework handle common errors

---

## Bundled Resources

### Scripts Directory
- `init_skill.py`: Initialize new skill with proper structure
- `package_skill.py`: Validate and package skill into distributable zip
- `quick_validate.py`: Quick validation of skill structure

### References Directory
- `design_spec.md`: Complete FastGPT tool design specification (10 sections)
- `requirement_template.md`: Template for creating tool requirement documents

### Usage Pattern
1. For detailed technical specifications → Read `references/design_spec.md`
2. For creating new tool requirements → Use `references/requirement_template.md`
3. For skill management → Use `scripts/*.py` utilities

---

## Related Documentation
- Tool Types: `ToolTypeEnum` in `@tool/type/tool`
- Config Types: `ToolConfigType`, `ToolSetConfigType` in `@tool/type`
- FastGPT Types: `WorkflowIOValueTypeEnum`, `FlowNodeInputTypeEnum`
